import random
import tkinter as tk
from tkinter import messagebox, simpledialog
import nltk
from nltk.corpus import words
import os
import csv
import threading

# Download words if missing
try:
    word_set = set(words.words())
except LookupError:
    nltk.download('words')
    word_set = set(words.words())

# Weighted Letter Pool
letter_weights = {
    "E": 107, "S": 89, "I": 84, "A": 70, "R": 66, "N": 64, "T": 62, "O": 61,
    "L": 49, "C": 38, "D": 31, "U": 30, "P": 27, "M": 26, "G": 25, "H": 21,
    "B": 17, "Y": 15, "F": 11, "V": 9, "K": 7, "W": 6, "Z": 4, "X": 2, "J": 1, "Q": 1
}
letter_pool = [letter for letter, weight in letter_weights.items() for _ in range(weight)]

# Define grid size
grid_size = 4 # anything >4 takes a LONG time!
max_grid_size = int(len(letter_pool)**0.5)
if grid_size > max_grid_size:
    grid_size = max_grid_size

# Generate Letter Grid
def generate_grid():
    grid = []
    for _ in range(grid_size):
        row = []
        for _ in range(grid_size):
            chosen_letter = random.choice(letter_pool)  # Pick a random letter
            letter_pool.remove(chosen_letter)  # Remove one occurrence of the chosen letter
            row.append(chosen_letter)
        grid.append(row)
    return grid

# Check if a position is within the grid bounds
def in_bounds(x, y):
    return 0 <= x < grid_size and 0 <= y < grid_size

# Search words recursively
def find_words(grid, x, y, path, visited, found_words):
    word = "".join(path)
    if len(word) >= 3 and word.lower() in word_set:
        found_words.add(word.lower())

    # Move in all 8 possible directions
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    for dx, dy in directions:
        nx, ny = x + dx, y + dy
        if in_bounds(nx, ny) and (nx, ny) not in visited:
            find_words(grid, nx, ny, path + [grid[nx][ny]], visited | {(nx, ny)}, found_words)

# Scan entire grid for words
def find_all_words(grid):
    found_words = set()
    for x in range(grid_size):
        for y in range(grid_size):
            find_words(grid, x, y, [grid[x][y]], {(x, y)}, found_words)
    return found_words

# Organize words into tuples by length
def group_words_by_length(words):
    word_dict = {}
    for word in words:
        word_dict.setdefault(len(word), []).append(word)
    return {length: tuple(sorted(words)) for length, words in sorted(word_dict.items())}

# GUI Setup
def create_gui(grid, grouped_words, max_points):
    # Tkinter GUI creation code
    root = tk.Tk()
    root.title("WordSquare")
    root.geometry("360x640")

    # Create Letter Grid Display
    grid_frame = tk.Frame(root)
    grid_frame.pack()
    for i in range(grid_size):
        for j in range(grid_size):
            tk.Label(grid_frame, text=grid[i][j], font=("Arial", 18), width=3, height=2, borderwidth=2, relief="groove").grid(row=i, column=j, padx=2, pady=2)

    # Word Entry
    entry_label = tk.Label(root, text="Enter a word:", font=("Arial", 14))
    entry_label.pack()
    entry = tk.Entry(root, font=("Arial", 14))
    entry.pack()
    word_listbox = tk.Listbox(root, width=49, height=15, font=("Arial", 9))
    word_listbox.pack()

    # Score Display
    score_label = tk.Label(root, text="Score: 0 (0.0%)", font=("Arial", 14))
    score_label.pack()

    score = 0
    player_words = set()

    def submit_word(event=None):
        nonlocal score
        word = entry.get().lower()

        if word in found_words and len(word) >= 3 and word not in player_words:
            player_words.add(word)
            word_listbox.delete(0, tk.END)
            for w in sorted(player_words):
                word_listbox.insert(tk.END, w)
            score += len(word) ** 2
            score_label.config(text=f"Score: {score} ({round(score/max_points*100,1)}%)")
        entry.delete(0, tk.END)

    # Save game results
    def save_results():
        nonlocal score
        if score > 0:
            score_file = "word_square_scores.csv"
            player_name = simpledialog.askstring("Player Name", "Enter your name:")
            if not player_name:
                player_name = "Anonymous"

            scores = []
            if os.path.exists(score_file):
                with open(score_file, mode="r", newline="") as file:
                    reader = csv.reader(file)
                    header = next(reader, None)
                    scores = [row for row in reader]

            scores.append([player_name, str(score), f"{round(score/max_points*100, 1)}%"])
            scores.sort(key=lambda x: int(x[1]), reverse=True)

            with open(score_file, mode="w", newline="") as file:
                writer = csv.writer(file)
                writer.writerow(["Player", "Score", "Percentage"])
                writer.writerows(scores)

            messagebox.showinfo("Game Over", f"Score saved!\nPlayer: {player_name}\nScore: {score}\n({round(score/max_points*100,1)}%)")
            root.destroy()

    finish_button = tk.Button(root, text="Finish & Save Score", font=("Arial", 14), command=save_results)
    finish_button.pack()

    entry.bind("<Return>", submit_word)

    root.mainloop()

# Function to handle word search in the background thread
def search_words_in_background(grid, grouped_words, max_points):
    found_words = find_all_words(grid)
    grouped_words = group_words_by_length(found_words)
    
    # Once the words are found, update the GUI with the results
    create_gui(grid, grouped_words, max_points)

# Main function to launch the game
def launch_word_square():
    grid = generate_grid()
    print("Word Grid:")
    for row in grid:
        print(" ".join(row))
    print()

    # Group words by length and calculate the score
    found_words = find_all_words(grid)
    grouped_words = group_words_by_length(found_words)

    points_required = 0
    max_points = 0
    for length, word_tuple in grouped_words.items():
        points = len(word_tuple) * length**2
        max_points += points
        points_required += (points / 3)
        points_required = int(points_required)
    print(f"Suggested points goal = {points_required} from {max_points} available.")

    # Run the word search in the background to keep the UI responsive
    word_search_thread = threading.Thread(target=search_words_in_background, args=(grid, grouped_words, max_points))
    word_search_thread.start()
