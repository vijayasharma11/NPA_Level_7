# Glasgow Code Learning Games App: Tic-Tac-Toe
# Author: Hymasri Moguluri 
# Date created : 18/02/2025
# last updated : 20/02/2025
# version      : 1.0
# Instructions : 
# just select from the menu of 3 options and choose a difficulty level, enter your name , make your move(choose a number between 1 and 9)



import csv
import random
import os
import sys

main_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(main_folder)
from scoreboard_manager import create_scoreboard, update_scoreboard

# Import scoreboard functions
from scoreboard_manager import create_scoreboard, update_scoreboard


# Function to display the game board
def display_board(board):
    """
    Displays the current Tic-Tac-Toe board.
    """
    print("\n")
    print(" | ".join(board[0]))
    print("--------")
    print(" | ".join(board[1]))
    print("--------")
    print(" | ".join(board[2]))
    print("\n")

# Function to check if the current player has won
def check_winner(board, player):
    """
    Checks if the player has won the game.

    Arguments:
    board - A 3x3 list representing the Tic-Tac-Toe board.
    player - 'X' or 'O', representing the current player.

    Returns:
    True if the player has won, otherwise False.
    """
    # Check rows
    if (board[0][0] == player and board[0][1] == player and board[0][2] == player):
        return True
    if (board[1][0] == player and board[1][1] == player and board[1][2] == player):
        return True
    if (board[2][0] == player and board[2][1] == player and board[2][2] == player):
        return True

    # Check columns
    if (board[0][0] == player and board[1][0] == player and board[2][0] == player):
        return True
    if (board[0][1] == player and board[1][1] == player and board[2][1] == player):
        return True
    if (board[0][2] == player and board[1][2] == player and board[2][2] == player):
        return True

    # Check diagonals
    if (board[0][0] == player and board[1][1] == player and board[2][2] == player):
        return True
    if (board[0][2] == player and board[1][1] == player and board[2][0] == player):
        return True

    return False

# Function to check if the board is full
def is_board_full(board):
    """
    Checks if the Tic-Tac-Toe board is full.
    """
    if board[0][0] != ' ' and board[0][1] != ' ' and board[0][2] != ' ' and \
       board[1][0] != ' ' and board[1][1] != ' ' and board[1][2] != ' ' and \
       board[2][0] != ' ' and board[2][1] != ' ' and board[2][2] != ' ':
        return True
    return False

# Function for the human player to make a move
def human_move(board):
    """
    Allows the human player to make a move.

    Arguments:
    board - The current Tic-Tac-Toe board.

    Returns:
    A tuple (row, col) representing the move.
    """
    valid_move = False
    while not valid_move:
        try:
            move = input("Enter your move (1-9): ")
             # Check if input is a number

            if move.isdigit(): 
                move = int(move)
                 # Ensure the move is between 1 and 9
                if move < 1 or move > 9:  
                    print("Invalid input! Please enter a number between 1 and 9.")
                    # Convert move to row, column
                else:
                    row, col = (move - 1) // 3, (move - 1) % 3  
                    if board[row][col] == ' ':
                        valid_move = True
                        return row, col
                    else:
                        print("Cell already taken! Choose another.")
            else:
                print("Invalid input! Please enter a number.")
        except ValueError:
            print("Invalid input! Please enter a valid number.")

# Function for the computer to make a move
def computer_move(board, difficulty='easy'):
    """
    Makes a move for the computer.

    Arguments:
    board - The current Tic-Tac-Toe board.
    difficulty - The difficulty level ('easy' or 'tough').

    Returns:
    A tuple (row, col) representing the computer's move.
    """
    valid_move = False
    while not valid_move:
        if difficulty == 'easy':
            # Random move
            move = random.randint(1, 9)  
        else:
            # Check for a winning move for 'O' or block for 'X'
            move = None
            for i in range(1, 10):
                row, col = (i - 1) // 3, (i - 1) % 3
                if board[row][col] == ' ':
                    board[row][col] = 'O'
                    if check_winner(board, 'O'):
                        move = i
                        break
                    # Reset
                    board[row][col] = ' ' 
                    board[row][col] = 'X'
                    if check_winner(board, 'X'):
                        move = i
                        break
                     # Reset
                    board[row][col] = ' ' 

            # If no winning or blocking move, choose a random move
            if move is None:
                move = random.randint(1, 9)

        row, col = (move - 1) // 3, (move - 1) % 3
        if board[row][col] == ' ':
            valid_move = True
            return row, col
        # Retry if the cell is already taken
        else:
            valid_move = False  
            
# Function to play the Tic-Tac-Toe game
def play_game():
    """
    Plays a game of Tic-Tac-Toe between the human and the computer.
    """
    game_name = "Tic-Tac-Toe"
    create_scoreboard(game_name)
    player_name = input("Enter your name: ")
    board = [[' ' for _ in range(3)] for _ in range(3)]
    current_player = 'O'
    winner = None

    difficulty = input("Choose difficulty (easy/tough): ").lower()
    if difficulty not in ['easy', 'tough']:
        print("Invalid difficulty! Defaulting to 'easy'.")
        difficulty = 'easy'

    while not is_board_full(board) and winner is None:
        display_board(board)
        if current_player == 'X':
            row, col = human_move(board)
        else:
            row, col = computer_move(board, difficulty)

        board[row][col] = current_player
        if check_winner(board, current_player):
            winner = current_player
        current_player = 'X' if current_player == 'O' else 'O'

    display_board(board)
    # Win score
    
    if winner:
        print(f"{'Computer' if winner == 'O' else 'You'} win!")
        return 100 
    # Draw score 
    else:
        print("It's a tie!")
        return 50  
        update_scoreboard(game_name, player_name, score)

# Function to save the score to a CSV file

def save_score(name, score):
    """
    Saves the score to a CSV file.
    """
    try:
        # Define the file path. Use an absolute path if necessary.
        file_path = "scores.csv"

        # Open the file in append mode
        with open(file_path, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([name, score])
            print(f"Score saved: {name} - {score} points")
            
    except Exception as e:
        # Print error message for debugging
        print(f"Error saving score: {e}")
        print(f"Could not write to {file_path}. Check if the directory is writeable and if the file is in use by another process.")


# Function to display the leaderboard
def display_leaderboard():
    """
    Displays the leaderboard by reading scores from a CSV file.
    """
    try:
        if not os.path.exists("scores.csv"):
            print("No scores found yet!")
            return

        with open("scores.csv", "r") as file:
            reader = csv.reader(file)
            scores = []
            for row in reader:
                try:
                    # Check if score is valid
                    if row[1].isdigit():
                        scores.append((row[0], int(row[1])))
                        # Skip invalid rows
                except ValueError:
                    continue  

            if not scores:
                print("No valid scores available!")
                return

            scores.sort(key=lambda x: x[1], reverse=True)

            print("\nLeaderboard:")
            for rank, (name, score) in enumerate(scores, 1):
                print(f"{rank}. {name} - {score} points")
    except Exception as e:
        print(f"Error displaying leaderboard: {e}")

# Main menu function
def launch_Tic_Tac_Toe():
    """
    Displays the main menu and handles user choice.
    """
    while True:
        print("\nTic-Tac-Toe Game")
        print("1) Play the Game")
        print("2) View Leaderboard")
        print("3) Exit")
        choice = input("Choose an option (1-3): ")
        if choice == '1':
            name = input("Enter your name: ")
            score = play_game()
            save_score(name, score)
        elif choice == '2':
            display_leaderboard()
        elif choice == '3':
            print("Exiting the game. Goodbye!")
            break
        else:
            print("Invalid choice! Please select a number between 1 and 3.")
            update_scoreboard(game_name, player_name, score)

# Run the program
if __name__ == "__main__":
  launch_tic_tac_toe()

