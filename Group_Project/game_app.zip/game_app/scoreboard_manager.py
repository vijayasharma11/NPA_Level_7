import csv
import os

SCOREBOARD_FILE = "scoreboard.csv"

def create_scoreboard(game_name):
    """
    Creates a scoreboard file if it does not exist.
    """
    if not os.path.exists(SCOREBOARD_FILE):
        with open(SCOREBOARD_FILE, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Game", "Player", "Score"])  # Header row
        print(f"Scoreboard created for {game_name}.")

def update_scoreboard(game_name, player_name, score):
    """
    Updates the scoreboard with the player's score.

    Args:
        game_name (str): Name of the game.
        player_name (str): Player's name.
        score (int): Score obtained in the game.
    """
    try:
        with open(SCOREBOARD_FILE, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([game_name, player_name, score])
        print(f"Score updated: {player_name} - {score} points")
    except Exception as e:
        print(f"Error updating scoreboard: {e}")

def display_leaderboard():
    """
    Displays the top scores from the scoreboard file.
    """
    try:
        if not os.path.exists(SCOREBOARD_FILE):
            print("No scores recorded yet!")
            return

        with open(SCOREBOARD_FILE, "r") as file:
            reader = csv.reader(file)
            scores = []
            next(reader, None)  # Skip header row

            for row in reader:
                if len(row) == 3 and row[2].isdigit():
                    scores.append((row[0], row[1], int(row[2])))

            if not scores:
                print("No valid scores found!")
                return

            scores.sort(key=lambda x: x[2], reverse=True)  # Sort by score (highest first)

            print("\nLeaderboard:")
            for rank, (game, player, score) in enumerate(scores, 1):
                print(f"{rank}. {player} ({game}) - {score} points")

    except Exception as e:
        print(f"Error displaying leaderboard: {e}")
